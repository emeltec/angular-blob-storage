export const environment = {
  production: true,
  sasGeneratorUrl: 'https://stottle-blob-storage-api.azurewebsites.net'
};

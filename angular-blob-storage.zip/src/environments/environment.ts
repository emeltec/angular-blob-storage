export const environment = {
  production: false,
  sasGeneratorUrl: 'https://blob-storage-api.azurewebsites.net'
  //sasGeneratorUrl: 'https://stottle-blob-storage-api.azurewebsites.net'
};
